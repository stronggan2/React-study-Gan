import React from "react";
import "./Prac01.scss";

const prac01 = () => {
  return (
    <div className="box">
      <div className="squire"></div>
      <div className="squire"></div>
      <div className="squire"></div>
      <div className="squire"></div>
      <div className="squire"></div>
      <div className="squire"></div>
      <div className="squire"></div>
    </div>
  );
};

export default prac01;
